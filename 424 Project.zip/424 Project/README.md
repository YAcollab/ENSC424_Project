# 424 Project – RTSP Webcam Demo
This project turns your webcam into a local RTSP video stream using Python, OpenCV, and MediaMTX.


## How to run
1. Install **Python 3** and **VLC Media Player** on your computer.
2. Download/unzip this folder so you have:

   - `rtsp-stream/`
   - `scripts/`
   - `README`

3. Open the `scripts` folder.
4. Double-click **`run_windows.bat`**.

The first time you run it, the script will:

- create a local Python virtual environment in a new `.venv` folder,
- install the required Python packages,
- start the RTSP server and camera script,
- open VLC to show the video.

Keep the terminal windows open while you are using the stream.



## What to expect
- Your **webcam light** will turn on.
- **VLC** will open and show the live webcam video.
- When you close VLC and the terminal windows, the stream stops.
Everything runs **locally on your machine**.